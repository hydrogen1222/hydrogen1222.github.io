# 通用 PBE/HSE06 → SCDM → Wannier90 能带 Workflow

这个目录可以独立复制使用。你负责先完成一次 PBE 或 HSE06 的均匀 k 网格计算；脚本自动识别泛函，然后使用该计算的波函数（PBE 原网格过密时使用 `CHGCAR` 固定密度重采样），完成 SCDM 初始投影、Wannier90 插值、插值误差校验、全布里渊区带隙扫描和能带作图。

## PBE 和 HSE06 能否使用同一套后处理？

可以。Wannier90 接收的是 VASP 产生的 Bloch 波函数、本征能和相邻 k 点波函数重叠矩阵，并不负责计算 PBE 或 HSE06 交换关联势。因此，从 SCDM 导出以后，两种泛函的 Wannier90 解纠缠、局域化、插值、带隙扫描和画图流程相同。

主要区别发生在前面的 VASP 计算：

- PBE 的 Bloch 波函数和本征值来自 PBE Hamiltonian；
- HSE06 的 Bloch 波函数和本征值来自含屏蔽精确交换的 HSE06 Hamiltonian；
- HSE06 Hamiltonian 依赖规则 k 网格上的轨道，不能像普通 PBE 能带那样只靠 `CHGCAR` 做常规非自洽 line-mode 计算；
- 本 Workflow 为了统一和稳妥，对 PBE/HSE06 都要求保存相应的均匀网格 `WAVECAR`。

所以不能拿 PBE 的 `WAVECAR` 画出 HSE06 能带，也不能反过来。两个计算应分别放在不同目录，Workflow 会分别得到 `PBE_Wannier90_bands.*` 或 `HSE06_Wannier90_bands.*`。

对于 PBE，直接用 `CHGCAR + line-mode KPOINTS` 画能带通常更便宜，并非必须使用 Wannier90。但如果希望和 HSE06 采用完全一致的插值、全区带隙搜索和输出格式，使用本 Workflow 很合适。

## 高对称路径到底用在哪里？

晶体的能量是三维函数 \(E_n(\mathbf{k})\)，常见的二维能带图不可能画出整个三维布里渊区，所以通常只沿若干具有代表性的高对称线取一条路径，例如 FCC 晶格中的 Γ–X–W–K–Γ–L……。

高对称路径只用于最后的“沿线取样和画图”：

- 不参与原始 PBE/HSE06 均匀网格计算；
- 不参与 SCDM 初始投影；
- 不参与 Wannier 函数的解纠缠和局域化；
- 不用于最终的全布里渊区 VBM/CBM 搜索。

因此，VBM/CBM 和基本带隙由致密全区扫描判断；高对称路径只是把 Wannier Hamiltonian 切成一条大家容易阅读的能带曲线。如果极值不在高对称线上，图中可能看不到它，但全区扫描仍能找到它。

用户不需要提供路径。本 Workflow 固定使用 pymatgen 的 `HighSymmKpath`，按照 Setyawan–Curtarolo 约定，根据 `POSCAR` 的晶体对称性自动识别空间群、特殊 k 点和连接路径。不同软件采用不同约定时，路径可能略有差异，但不会改变独立的全区扫描结果。

自动高对称路径要求输入为标准原胞。脚本会在昂贵的 Wannier 计算之前检查这一点；如果 `POSCAR` 不是 pymatgen 所需的标准原胞，会直接停止。对新材料，应该先确定标准原胞，再用同一个原胞完成 PBE/HSE06 均匀网格计算。

## PBE/HSE06 单点结束后能得到直接带隙吗？

能得到均匀网格上的判断，但它不是对连续布里渊区的严格证明：

- 脚本从输入 `EIGENVAL` 找出所采样 k 点中的 VBM 和 CBM；两者是同一个 k 点时，报告 `Direct on the input mesh: True`。
- 如果只计算一个 Γ 点，只能得到 Γ 点的价带—导带差，不能判断全布里渊区的基本带隙。
- 即使使用均匀网格，真正极值也可能位于网格点之间，所以 Workflow 会再使用 Wannier Hamiltonian 做默认 `24×24×24` 全区扫描。

Wannier90 不会提高源泛函本身的物理准确性。它提高的是 k 空间取样的密度；PBE 是否低估带隙、HSE06 参数是否合适、原始 k 网格是否收敛，仍是独立的物理问题。

致密扫描本身仍是有限网格，并非数学上的连续极值搜索。对带隙要求很高时，可分别用 `GAP_SCAN_MESH=18`、`24`、`30` 检查带隙是否稳定；通常应报告已经对扫描网格收敛的位数，而不是机械照抄九位小数。

## 当前适用范围

- PBE：`GGA=PE`、`LHFCALC=.FALSE.`；
- HSE06：`GGA=PE`、`LHFCALC=.TRUE.`、`AEXX=0.25`、`HFSCREEN=0.20`；
- 闭壳层半导体或绝缘体；
- `ISPIN=1`、`LSORBIT=.FALSE.`；
- 自动均匀 Γ-centered 或 Monkhorst-Pack k 网格；
- 静态单点计算，即 `NSW=0`；
- 至少包含一条空带，建议保留若干条空带。

当前版本会拒绝金属、奇数电子、自旋极化、SOC 以及其他泛函。这些体系需要另外处理占据数、自旋通道或投影，不能直接套用当前自动参数。

## 软件和输入

需要 VASP 6（编译了 VASP2WANNIER90 接口）、`wannier90.x`、`postw90.x`、MPI，以及 Python 包 `numpy`、`matplotlib`、`pymatgen`。

输入目录必须包含非空文件：

```text
POSCAR  POTCAR  KPOINTS  WAVECAR  EIGENVAL  OUTCAR
```

`OUTCAR` 必须正常结束，并且是 `NSW=0` 的静态单点。结构优化结束后，应使用最终 `CONTCAR` 作为新单点计算的 `POSCAR`，不要直接把优化目录交给本 Workflow。`WAVECAR` 必须和同目录的结构、赝势、均匀 k 网格及 `ENCUT` 对应。脚本会从原 `OUTCAR` 继承实际 `ENCUT`，避免复用波函数时改变平面波基组。PBE 输入还应保留 `CHGCAR`：当原网格比 `12×12×12` 更密时，Workflow 会自动用固定 PBE 电荷密度生成较适合 Wannier 构造的网格，避免数万 k 点造成超大 `.mmn` 文件。

## 一键运行

```bash
cd /home/storm/vasp/LPSC/another/vasp_wannier90_workflow

./run_vasp_wannier.sh /path/to/PBE_or_HSE06 /path/to/new_output
```

例如：

```bash
./run_vasp_wannier.sh ../pbe_single_point ../Li6PS5Cl_PBE_w90
./run_vasp_wannier.sh ../h06             ../Li6PS5Cl_HSE06_w90
```

输出目录必须尚不存在，防止覆盖旧结果。不填写输出目录时，默认使用 `输入目录名_wannier90`。

## 常用选项

```bash
W90_NPROCS=4 \
GAP_SCAN_MESH=24 \
PLOT_EMIN=-8 \
./run_vasp_wannier.sh /path/to/input /path/to/output
```

- `W90_NPROCS`：VASP/SCDM 导出以及 MPI 版 Wannier90/postw90 使用的最大进程数，默认 4；脚本会自动降低到能够整除输入 `NBANDS` 的最大数，避免 VASP 增补未经源计算收敛的空带；
- `USE_SOURCE_KMESH=1`：明确要求 Wannier 构造完整保留原始均匀网格；默认值为 0，此时过密 PBE 网格受下一项上限控制；
- `WANNIER_MESH_MAX`：PBE Wannier 构造网格每个方向的上限，默认 12；原 PBE 网格更密时自动从 `CHGCAR` 固定密度重采样。HSE06 不做这种重采样，因为杂化泛函依赖规则网格上的轨道；
- `NUM_WANN`：覆盖自动选择的 Wannier 函数数目；
- `GAP_SCAN_MESH`：全区扫描每个方向的点数，默认 24；
- `PLOT_EMIN`：相对 VBM 的作图最低能量，默认 −10 eV；
- `VASP_EXE`、`WANNIER90_EXE`、`POSTW90_EXE`、`MPIRUN_EXE`：可执行文件位置；
- `VASP_COMMAND`：完整的自定义 VASP 启动命令。

若研究目的就是比较密集 Wannier 构造网格，可显式保留源网格：

```bash
USE_SOURCE_KMESH=1 ./run_vasp_wannier.sh /path/to/input /path/to/new_output
```

当完整网格超过 9999 个 k 点时，VASP 6.6.0 的 `.mmn/.amn` 记录采用相邻的 `I5` 整数字段，五位数编号之间可能没有分隔空格。Workflow 会自动进行等长的空白字符规范化；只修改整数索引的分隔符，不改变任何复数重叠矩阵或投影值，并将记录写入 `mmn_header_repair_report.txt` 和 `amn_header_repair_report.txt`。

密集源网格模式下，Workflow 在原始不可约 k 点上校验 Wannier 对 VBM、CBM 和带隙的复现。如果保留的源网格在三个方向都不低于 `GAP_SCAN_MESH`，脚本直接采用更密的源网格带隙报告，不再额外执行一个更稀疏且计算昂贵的 Wannier 全区扫描。

## Workflow 的十个步骤

1. 自动识别 PBE/HSE06，检查计算完成状态、电子数、能带数和均匀 k 网格；
2. 报告输入网格上的 VBM、CBM、带隙和直接/间接性质；
3. pymatgen 自动识别晶体并生成 Setyawan–Curtarolo 高对称路径；
4. 复用 `WAVECAR`，或对过密 PBE 网格使用 `CHGCAR` 固定密度重采样，通过一步 VASP/SCDM 生成 `.amn/.mmn/.eig`；
5. 自动确定 `NUM_WANN`、outer window 和 frozen window；
6. 执行 Wannier90 解纠缠、局域化与高对称路径插值；
7. 在 Wannier 构造网格的全部 k 点上逐点校验 Wannier 与 PBE/HSE06 带边，默认误差超过 `1e-5 eV` 即停止；
8. 若 PBE 原网格被自动缩小，则在原始致密网格上交叉验证 VBM、CBM 和带隙，默认允许差异为 0.02 eV；
9. 在致密全布里渊区网格上重新寻找 VBM/CBM；
10. 输出 PNG、PDF、CSV、实空间 Hamiltonian 和汇总报告。

## 主要输出

```text
input_mesh_gap_report.txt       输入均匀网格的带隙
validation_report.txt           Wannier 对输入本征值的校验
source_mesh_validation_report.txt  缩小 PBE 构造网格时，对原始致密网格的交叉验证
dense_gap_scan_report.txt       致密全区 VBM、CBM 和带隙
PBE_Wannier90_bands.*           PBE 的 PNG/PDF/CSV
HSE06_Wannier90_bands.*         HSE06 的 PNG/PDF/CSV
wannier90_hr.dat                Wannier 实空间 Hamiltonian
workflow_metadata.json          自动参数、泛函和结构信息
RESULTS.md                      汇总报告
```

判断结果时应先确认 Workflow 正常结束，并检查 `validation_report.txt` 的带边误差。复杂体系如果自动 SCDM/能窗不收敛，不应只看生成的图片；这时需要增加源计算的空带数或针对体系设计投影与能窗。

## `workflow.py` 是做什么的？

`run_vasp_wannier.sh` 是用户入口和总调度器，负责依次启动 VASP、Wannier90 和 postw90。`workflow.py` 是被 shell 脚本反复调用的辅助程序，负责读取和写入这些程序不方便自动处理的数据：

- 解析 `OUTCAR/EIGENVAL/KPOINTS/POSCAR`，识别泛函、电子数、带隙和网格；
- 在 PBE 原网格过密时生成较合适的 Wannier 构造 `KPOINTS`；
- 用 pymatgen 生成高对称路径；
- 自动生成导出 `INCAR` 和正式 `wannier90.win`；
- 比较原始本征值与 Wannier 插值误差；
- 搜索致密网格上的 VBM/CBM；
- 生成 PNG、PDF、CSV 和 `RESULTS.md`。

正常使用时不需要单独执行 `workflow.py`；只运行 `run_vasp_wannier.sh` 即可。结果也不会写在脚本旁边，而是写入命令第二个参数指定的输出目录，例如 `./results/PBE_Wannier90_bands.png`。
