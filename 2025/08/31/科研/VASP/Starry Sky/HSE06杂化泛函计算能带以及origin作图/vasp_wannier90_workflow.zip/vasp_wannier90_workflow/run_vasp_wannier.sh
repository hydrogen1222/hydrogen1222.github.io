#!/usr/bin/env bash
set -euo pipefail

usage() {
    cat <<'EOF'
Usage:
  run_vasp_wannier.sh PBE_OR_HSE06_DIR [OUTPUT_DIR]

Example:
  ./run_vasp_wannier.sh ../pbe ../pbe_w90
  ./run_vasp_wannier.sh ../hse06 ../hse06_w90

The input directory must contain POSCAR, POTCAR, KPOINTS, WAVECAR,
EIGENVAL, and OUTCAR. PBE/HSE06 must use an automatic uniform k mesh.
This workflow currently supports closed-shell ISPIN=1 systems without SOC.

Optional environment variables:
  W90_NPROCS=4             Maximum MPI ranks for the one-step VASP export;
                           automatically reduced to a divisor of input NBANDS
  NUM_WANN=...             Override the automatically suggested number of WFs
  USE_SOURCE_KMESH=1       Keep the original dense PBE/HSE06 mesh exactly;
                           default 0 permits the PBE mesh cap below
  WANNIER_MESH_MAX=12      Cap each PBE Wannier-construction mesh direction;
                           a denser PBE input is resampled from CHGCAR
  SOURCE_VALIDATION_TOL=0.02  Maximum band-edge error against dense PBE source (eV)
  GAP_SCAN_MESH=24         Dense full-zone band-gap mesh
  PLOT_EMIN=-10            Lower energy limit relative to the VBM (eV)
  VASP_EXE=/path/vasp_std  VASP executable
  WANNIER90_EXE=/path/...  wannier90.x executable
  POSTW90_EXE=/path/...    postw90.x executable
  VASP_COMMAND='...'       Complete custom VASP launch command; overrides
                           VASP_EXE and W90_NPROCS for launching only
EOF
}

if [[ ${1:-} == "-h" || ${1:-} == "--help" ]]; then
    usage
    exit 0
fi
if [[ $# -lt 1 || $# -gt 2 ]]; then
    usage >&2
    exit 2
fi

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
HELPER="$SCRIPT_DIR/workflow.py"
SEED=wannier90
SOURCE_DIR=$(realpath "$1")
if [[ $# -eq 2 ]]; then
    OUTPUT_DIR=$(realpath -m "$2")
else
    OUTPUT_DIR="${SOURCE_DIR%/}_wannier90"
fi

REQUESTED_W90_NPROCS=${W90_NPROCS:-4}
WANNIER_MESH_MAX=${WANNIER_MESH_MAX:-12}
USE_SOURCE_KMESH=${USE_SOURCE_KMESH:-0}
SOURCE_VALIDATION_TOL=${SOURCE_VALIDATION_TOL:-0.02}
GAP_SCAN_MESH=${GAP_SCAN_MESH:-24}
PLOT_EMIN=${PLOT_EMIN:--10.0}
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-1}

find_executable() {
    local requested=$1
    local name=$2
    local fallback=$3
    if [[ -n "$requested" ]]; then
        if [[ -x "$requested" ]]; then
            realpath "$requested"
        elif command -v "$requested" >/dev/null 2>&1; then
            command -v "$requested"
        else
            printf 'Cannot execute requested %s: %s\n' "$name" "$requested" >&2
            exit 1
        fi
    elif command -v "$name" >/dev/null 2>&1; then
        command -v "$name"
    elif [[ -x "$fallback" ]]; then
        printf '%s\n' "$fallback"
    else
        printf 'Cannot find %s. Set its path with an environment variable.\n' "$name" >&2
        exit 1
    fi
}

if [[ -z ${VASP_COMMAND:-} ]]; then
    VASP_EXE=$(find_executable "${VASP_EXE:-}" vasp_std /opt/apps/vasp/6.6.0/bin/vasp_std)
fi
WANNIER90_EXE=$(find_executable "${WANNIER90_EXE:-}" wannier90.x /opt/apps/wannier90/3.1.0/bin/wannier90.x)
POSTW90_EXE=$(find_executable "${POSTW90_EXE:-}" postw90.x /opt/apps/wannier90/3.1.0/bin/postw90.x)

log() {
    printf '[%(%F %T)T] %s\n' -1 "$*"
}

fail() {
    printf 'ERROR: %s\n' "$*" >&2
    exit 1
}

[[ "$REQUESTED_W90_NPROCS" =~ ^[1-9][0-9]*$ ]] || fail "W90_NPROCS must be a positive integer"
[[ "$WANNIER_MESH_MAX" =~ ^[1-9][0-9]*$ ]] || fail "WANNIER_MESH_MAX must be a positive integer"
[[ "$USE_SOURCE_KMESH" == 0 || "$USE_SOURCE_KMESH" == 1 ]] || fail "USE_SOURCE_KMESH must be 0 or 1"
[[ "$GAP_SCAN_MESH" =~ ^[1-9][0-9]*$ ]] || fail "GAP_SCAN_MESH must be a positive integer"
[[ -f "$HELPER" ]] || fail "Missing helper script: $HELPER"

read -r NELECT NKPTS PHYSICAL_NBANDS NOCC ISPIN SUGGESTED_NUM_WANN FUNCTIONAL \
    SOURCE_MESH_X SOURCE_MESH_Y SOURCE_MESH_Z < <(
    python3 "$HELPER" inspect --source-dir "$SOURCE_DIR"
)
NUM_WANN=${NUM_WANN:-$SUGGESTED_NUM_WANN}
[[ "$NUM_WANN" =~ ^[1-9][0-9]*$ ]] || fail "NUM_WANN must be a positive integer"
(( NUM_WANN > NOCC )) || fail "NUM_WANN must be larger than the occupied-band count ($NOCC)"
(( NUM_WANN <= PHYSICAL_NBANDS )) || fail "NUM_WANN cannot exceed input NBANDS ($PHYSICAL_NBANDS)"
W90_NPROCS=$REQUESTED_W90_NPROCS
(( W90_NPROCS <= PHYSICAL_NBANDS )) || W90_NPROCS=$PHYSICAL_NBANDS
while (( PHYSICAL_NBANDS % W90_NPROCS != 0 )); do
    W90_NPROCS=$((W90_NPROCS - 1))
done
POST_NBANDS=$PHYSICAL_NBANDS
EXPORT_MODE=reuse-wavecar
CONSTRUCTION_MODE="reuse source WAVECAR"
CONSTRUCTION_MESH_X=$SOURCE_MESH_X
CONSTRUCTION_MESH_Y=$SOURCE_MESH_Y
CONSTRUCTION_MESH_Z=$SOURCE_MESH_Z
if [[ "$USE_SOURCE_KMESH" == 1 ]]; then
    CONSTRUCTION_MODE="reuse complete source WAVECAR (dense mesh explicitly requested)"
elif (( SOURCE_MESH_X > WANNIER_MESH_MAX \
      || SOURCE_MESH_Y > WANNIER_MESH_MAX \
      || SOURCE_MESH_Z > WANNIER_MESH_MAX )); then
    if [[ "$FUNCTIONAL" != PBE ]]; then
        fail "The HSE06 mesh ${SOURCE_MESH_X}x${SOURCE_MESH_Y}x${SOURCE_MESH_Z} is too large for automatic Wannier construction. Use an HSE06 source mesh no larger than ${WANNIER_MESH_MAX} in each direction."
    fi
    [[ -s "$SOURCE_DIR/CHGCAR" ]] \
        || fail "A dense PBE mesh needs CHGCAR for automatic fixed-density resampling"
    EXPORT_MODE=pbe-fixed-density
    CONSTRUCTION_MODE="PBE fixed-density resampling from CHGCAR"
    (( CONSTRUCTION_MESH_X > WANNIER_MESH_MAX )) && CONSTRUCTION_MESH_X=$WANNIER_MESH_MAX
    (( CONSTRUCTION_MESH_Y > WANNIER_MESH_MAX )) && CONSTRUCTION_MESH_Y=$WANNIER_MESH_MAX
    (( CONSTRUCTION_MESH_Z > WANNIER_MESH_MAX )) && CONSTRUCTION_MESH_Z=$WANNIER_MESH_MAX
fi
CONSTRUCTION_MESH="${CONSTRUCTION_MESH_X}x${CONSTRUCTION_MESH_Y}x${CONSTRUCTION_MESH_Z}"
PATH_DESCRIPTION=$(python3 "$HELPER" path-info \
    --poscar "$SOURCE_DIR/POSCAR")

if [[ -e "$OUTPUT_DIR" ]]; then
    fail "Output path already exists: $OUTPUT_DIR. Choose a new output directory."
fi
mkdir -p "$OUTPUT_DIR"

python3 "$HELPER" inspect \
    --source-dir "$SOURCE_DIR" \
    --report "$OUTPUT_DIR/input_mesh_gap_report.txt" >/dev/null

log "Detected functional: $FUNCTIONAL"
log "PBE/HSE06 input: $SOURCE_DIR"
log "Output: $OUTPUT_DIR"
log "NELECT=$NELECT, occupied bands=$NOCC, physical bands=$PHYSICAL_NBANDS"
log "Source mesh: ${SOURCE_MESH_X}x${SOURCE_MESH_Y}x${SOURCE_MESH_Z}"
log "Wannier construction: $CONSTRUCTION_MODE on $CONSTRUCTION_MESH"
log "NUM_WANN=$NUM_WANN, export NBANDS=$POST_NBANDS, MPI ranks=$W90_NPROCS"
if (( W90_NPROCS != REQUESTED_W90_NPROCS )); then
    log "MPI ranks reduced from $REQUESTED_W90_NPROCS to $W90_NPROCS to preserve NBANDS exactly"
fi
log "Band path: $PATH_DESCRIPTION"

for file in POSCAR POTCAR; do
    cp -p "$SOURCE_DIR/$file" "$OUTPUT_DIR/$file"
done
cp -p "$SOURCE_DIR/KPOINTS" "$OUTPUT_DIR/KPOINTS.input"
if [[ "$EXPORT_MODE" == pbe-fixed-density ]]; then
    cp -p "$SOURCE_DIR/CHGCAR" "$OUTPUT_DIR/CHGCAR"
    python3 "$HELPER" write-kpoints \
        --source "$SOURCE_DIR/KPOINTS" \
        --max-mesh "$WANNIER_MESH_MAX" \
        --output "$OUTPUT_DIR/KPOINTS" >/dev/null
else
    cp -p "$SOURCE_DIR/KPOINTS" "$OUTPUT_DIR/KPOINTS"
    cp -p "$SOURCE_DIR/WAVECAR" "$OUTPUT_DIR/WAVECAR"
fi
cp -p "$SOURCE_DIR/EIGENVAL" "$OUTPUT_DIR/EIGENVAL.input"
cp -p "$SOURCE_DIR/OUTCAR" "$OUTPUT_DIR/OUTCAR.input"

python3 "$HELPER" write-incar \
    --source-outcar "$SOURCE_DIR/OUTCAR" \
    --post-nbands "$POST_NBANDS" \
    --num-wann "$NUM_WANN" \
    --mode "$EXPORT_MODE" \
    --output "$OUTPUT_DIR/INCAR"

log "Running VASP SCDM/Wannier export"
if [[ -n ${VASP_COMMAND:-} ]]; then
    if ! (
        cd "$OUTPUT_DIR"
        bash -lc "$VASP_COMMAND" > vasp_export.stdout 2> vasp_export.stderr
    ); then
        fail "VASP export failed; inspect $OUTPUT_DIR/vasp_export.stderr and OUTCAR"
    fi
elif [[ -n ${SLURM_JOB_ID:-} ]]; then
    if ! (
        cd "$OUTPUT_DIR"
        srun -n "$W90_NPROCS" "$VASP_EXE" > vasp_export.stdout 2> vasp_export.stderr
    ); then
        fail "VASP export failed; inspect $OUTPUT_DIR/vasp_export.stderr and OUTCAR"
    fi
else
    MPIRUN_EXE=$(find_executable "${MPIRUN_EXE:-}" mpirun /opt/apps/openmpi509-intel/bin/mpirun)
    if ! (
        cd "$OUTPUT_DIR"
        "$MPIRUN_EXE" -np "$W90_NPROCS" "$VASP_EXE" > vasp_export.stdout 2> vasp_export.stderr
    ); then
        fail "VASP export failed; inspect $OUTPUT_DIR/vasp_export.stderr and OUTCAR"
    fi
fi

for file in wannier90.win wannier90.eig wannier90.mmn wannier90.amn OUTCAR; do
    [[ -s "$OUTPUT_DIR/$file" ]] || fail "VASP export did not produce $file; inspect vasp_export.stderr"
done
grep -q "General timing and accounting" "$OUTPUT_DIR/OUTCAR" \
    || fail "VASP export did not finish normally; inspect OUTCAR"

CONSTRUCTION_KPOINTS=$((CONSTRUCTION_MESH_X * CONSTRUCTION_MESH_Y * CONSTRUCTION_MESH_Z))
if (( CONSTRUCTION_KPOINTS > 9999 )); then
    log "Repairing VASP fixed-width MMN/AMN headers for five-digit k-point indices"
    python3 "$HELPER" repair-mmn \
        --mmn "$OUTPUT_DIR/wannier90.mmn" \
        --report "$OUTPUT_DIR/mmn_header_repair_report.txt"
    python3 "$HELPER" repair-amn \
        --amn "$OUTPUT_DIR/wannier90.amn" \
        --report "$OUTPUT_DIR/amn_header_repair_report.txt"
fi

cp -p "$OUTPUT_DIR/wannier90.win" "$OUTPUT_DIR/wannier90.win.vasp_setup"
if [[ -f "$OUTPUT_DIR/wannier90.wout" ]]; then
    cp -p "$OUTPUT_DIR/wannier90.wout" "$OUTPUT_DIR/wannier90.wout.vasp_setup"
fi
python3 "$HELPER" prepare-win \
    --setup-win "$OUTPUT_DIR/wannier90.win.vasp_setup" \
    --eig "$OUTPUT_DIR/wannier90.eig" \
    --physical-nbands "$PHYSICAL_NBANDS" \
    --nocc "$NOCC" \
    --num-wann "$NUM_WANN" \
    --functional "$FUNCTIONAL" \
    --construction-mode "$CONSTRUCTION_MODE" \
    --construction-mesh "$CONSTRUCTION_MESH" \
    --poscar "$OUTPUT_DIR/POSCAR" \
    --output-win "$OUTPUT_DIR/wannier90.win" \
    --metadata "$OUTPUT_DIR/workflow_metadata.json"

WANNIER90_LAUNCH=("$WANNIER90_EXE")
POSTW90_LAUNCH=("$POSTW90_EXE")
if ldd "$WANNIER90_EXE" 2>/dev/null | grep -q 'libmpi'; then
    if [[ -n ${SLURM_JOB_ID:-} ]]; then
        WANNIER90_LAUNCH=(srun -n "$W90_NPROCS" "$WANNIER90_EXE")
    else
        MPIRUN_EXE=$(find_executable "${MPIRUN_EXE:-}" mpirun /opt/apps/openmpi509-intel/bin/mpirun)
        WANNIER90_LAUNCH=("$MPIRUN_EXE" -np "$W90_NPROCS" "$WANNIER90_EXE")
    fi
fi
if ldd "$POSTW90_EXE" 2>/dev/null | grep -q 'libmpi'; then
    if [[ -n ${SLURM_JOB_ID:-} ]]; then
        POSTW90_LAUNCH=(srun -n "$W90_NPROCS" "$POSTW90_EXE")
    else
        MPIRUN_EXE=$(find_executable "${MPIRUN_EXE:-}" mpirun /opt/apps/openmpi509-intel/bin/mpirun)
        POSTW90_LAUNCH=("$MPIRUN_EXE" -np "$W90_NPROCS" "$POSTW90_EXE")
    fi
fi

log "Running Wannier90 disentanglement, localisation, and path interpolation"
log "Wannier90 launch: ${WANNIER90_LAUNCH[*]} $SEED"
if ! (
    cd "$OUTPUT_DIR"
    "${WANNIER90_LAUNCH[@]}" "$SEED" > wannier90.stdout 2> wannier90.stderr
); then
    fail "Wannier90 failed; inspect $OUTPUT_DIR/wannier90.stderr and wannier90.wout"
fi
for file in wannier90.chk wannier90_hr.dat wannier90_band.dat wannier90_band.labelinfo.dat; do
    [[ -s "$OUTPUT_DIR/$file" ]] || fail "Wannier90 did not produce $file; inspect wannier90.wout"
done
grep -q "All done: wannier90 exiting" "$OUTPUT_DIR/wannier90.wout" \
    || fail "Wannier90 did not finish normally; inspect wannier90.wout"
cp -p "$OUTPUT_DIR/wannier90.wout" "$OUTPUT_DIR/wannier90.wout.localisation"

if [[ "$USE_SOURCE_KMESH" == 1 ]] && (( CONSTRUCTION_KPOINTS > 9999 )); then
    log "Validating dense-mesh interpolation on the original irreducible source points"
    python3 "$HELPER" prepare-source-validation \
        --eigenval "$OUTPUT_DIR/EIGENVAL.input" \
        --output "$OUTPUT_DIR/wannier90_geninterp.kpt"
else
    log "Validating interpolation on the Wannier construction mesh"
    python3 "$HELPER" prepare-validation \
        --win "$OUTPUT_DIR/wannier90.win" \
        --output "$OUTPUT_DIR/wannier90_geninterp.kpt"
fi
if ! (
    cd "$OUTPUT_DIR"
    "${POSTW90_LAUNCH[@]}" "$SEED" > postw90_validation.stdout 2> postw90_validation.stderr
); then
    fail "postw90 validation failed; inspect $OUTPUT_DIR/postw90_validation.stderr"
fi
if [[ "$USE_SOURCE_KMESH" == 1 ]] && (( CONSTRUCTION_KPOINTS > 9999 )); then
    python3 "$HELPER" validate-source \
        --metadata "$OUTPUT_DIR/workflow_metadata.json" \
        --reference-eigenval "$OUTPUT_DIR/EIGENVAL.input" \
        --interpolated "$OUTPUT_DIR/wannier90_geninterp.dat" \
        --report "$OUTPUT_DIR/validation_report.txt" \
        --tolerance 1.0e-5
else
    python3 "$HELPER" validate \
        --metadata "$OUTPUT_DIR/workflow_metadata.json" \
        --reference "$OUTPUT_DIR/wannier90.eig" \
        --interpolated "$OUTPUT_DIR/wannier90_geninterp.dat" \
        --report "$OUTPUT_DIR/validation_report.txt"
fi
cp -p "$OUTPUT_DIR/wannier90_geninterp.kpt" "$OUTPUT_DIR/wannier90_geninterp_validation.kpt"
cp -p "$OUTPUT_DIR/wannier90_geninterp.dat" "$OUTPUT_DIR/wannier90_geninterp_validation.dat"
if [[ -f "$OUTPUT_DIR/wannier90.wpout" ]]; then
    cp -p "$OUTPUT_DIR/wannier90.wpout" "$OUTPUT_DIR/wannier90.wpout.validation"
fi

RESULTS_SOURCE_ARGUMENTS=()
if [[ "$EXPORT_MODE" == pbe-fixed-density ]]; then
    log "Cross-validating interpolation on the original dense PBE source mesh"
    python3 "$HELPER" prepare-source-validation \
        --eigenval "$OUTPUT_DIR/EIGENVAL.input" \
        --output "$OUTPUT_DIR/wannier90_geninterp.kpt"
    if ! (
        cd "$OUTPUT_DIR"
        "${POSTW90_LAUNCH[@]}" "$SEED" > postw90_source_validation.stdout 2> postw90_source_validation.stderr
    ); then
        fail "postw90 source validation failed; inspect $OUTPUT_DIR/postw90_source_validation.stderr"
    fi
    if ! python3 "$HELPER" validate-source \
        --metadata "$OUTPUT_DIR/workflow_metadata.json" \
        --reference-eigenval "$OUTPUT_DIR/EIGENVAL.input" \
        --interpolated "$OUTPUT_DIR/wannier90_geninterp.dat" \
        --report "$OUTPUT_DIR/source_mesh_validation_report.txt" \
        --tolerance "$SOURCE_VALIDATION_TOL"; then
        fail "Wannier interpolation does not reproduce the dense PBE source; increase WANNIER_MESH_MAX"
    fi
    cp -p "$OUTPUT_DIR/wannier90_geninterp.kpt" "$OUTPUT_DIR/wannier90_geninterp_source_validation.kpt"
    cp -p "$OUTPUT_DIR/wannier90_geninterp.dat" "$OUTPUT_DIR/wannier90_geninterp_source_validation.dat"
    RESULTS_SOURCE_ARGUMENTS=(--source-validation "$OUTPUT_DIR/source_mesh_validation_report.txt")
fi

if [[ "$USE_SOURCE_KMESH" == 1 ]] \
    && (( CONSTRUCTION_MESH_X >= GAP_SCAN_MESH \
          && CONSTRUCTION_MESH_Y >= GAP_SCAN_MESH \
          && CONSTRUCTION_MESH_Z >= GAP_SCAN_MESH )); then
    log "Using the retained $CONSTRUCTION_MESH source grid for the full-zone gap report"
    python3 "$HELPER" source-scan-report \
        --metadata "$OUTPUT_DIR/workflow_metadata.json" \
        --eigenval "$OUTPUT_DIR/EIGENVAL.input" \
        --mesh "$CONSTRUCTION_MESH" \
        --report "$OUTPUT_DIR/dense_gap_scan_report.txt"
else
    log "Scanning the full Brillouin zone on a ${GAP_SCAN_MESH}x${GAP_SCAN_MESH}x${GAP_SCAN_MESH} mesh"
    python3 "$HELPER" prepare-scan \
        --mesh "$GAP_SCAN_MESH" \
        --output "$OUTPUT_DIR/wannier90_geninterp.kpt"
    if ! (
        cd "$OUTPUT_DIR"
        "${POSTW90_LAUNCH[@]}" "$SEED" > postw90_scan.stdout 2> postw90_scan.stderr
    ); then
        fail "postw90 dense scan failed; inspect $OUTPUT_DIR/postw90_scan.stderr"
    fi
    python3 "$HELPER" scan-report \
        --metadata "$OUTPUT_DIR/workflow_metadata.json" \
        --kpoints "$OUTPUT_DIR/wannier90_geninterp.kpt" \
        --data "$OUTPUT_DIR/wannier90_geninterp.dat" \
        --report "$OUTPUT_DIR/dense_gap_scan_report.txt"
    cp -p "$OUTPUT_DIR/wannier90_geninterp.kpt" \
        "$OUTPUT_DIR/wannier90_geninterp_${GAP_SCAN_MESH}x${GAP_SCAN_MESH}x${GAP_SCAN_MESH}.kpt"
    cp -p "$OUTPUT_DIR/wannier90_geninterp.dat" \
        "$OUTPUT_DIR/wannier90_geninterp_${GAP_SCAN_MESH}x${GAP_SCAN_MESH}x${GAP_SCAN_MESH}.dat"
    if [[ -f "$OUTPUT_DIR/wannier90.wpout" ]]; then
        cp -p "$OUTPUT_DIR/wannier90.wpout" "$OUTPUT_DIR/wannier90.wpout.dense_scan"
    fi
fi
cp -p "$OUTPUT_DIR/wannier90_geninterp_validation.kpt" "$OUTPUT_DIR/wannier90_geninterp.kpt"
cp -p "$OUTPUT_DIR/wannier90_geninterp_validation.dat" "$OUTPUT_DIR/wannier90_geninterp.dat"

log "Generating PNG, PDF, and CSV band-structure outputs"
PLOT_PREFIX="${FUNCTIONAL}_Wannier90"
python3 "$HELPER" plot \
    --metadata "$OUTPUT_DIR/workflow_metadata.json" \
    --band-data "$OUTPUT_DIR/wannier90_band.dat" \
    --labels "$OUTPUT_DIR/wannier90_band.labelinfo.dat" \
    --emin "$PLOT_EMIN" \
    --png "$OUTPUT_DIR/${PLOT_PREFIX}_bands.png" \
    --pdf "$OUTPUT_DIR/${PLOT_PREFIX}_bands.pdf" \
    --csv "$OUTPUT_DIR/${PLOT_PREFIX}_bands.csv"

python3 "$HELPER" write-results \
    --metadata "$OUTPUT_DIR/workflow_metadata.json" \
    --mesh-gap "$OUTPUT_DIR/input_mesh_gap_report.txt" \
    --validation "$OUTPUT_DIR/validation_report.txt" \
    "${RESULTS_SOURCE_ARGUMENTS[@]}" \
    --scan "$OUTPUT_DIR/dense_gap_scan_report.txt" \
    --output "$OUTPUT_DIR/RESULTS.md"

log "Workflow completed successfully"
printf '\nMain outputs:\n'
printf '  %s\n' "$OUTPUT_DIR/input_mesh_gap_report.txt"
printf '  %s\n' "$OUTPUT_DIR/${PLOT_PREFIX}_bands.png"
printf '  %s\n' "$OUTPUT_DIR/${PLOT_PREFIX}_bands.pdf"
printf '  %s\n' "$OUTPUT_DIR/${PLOT_PREFIX}_bands.csv"
printf '  %s\n' "$OUTPUT_DIR/RESULTS.md"
