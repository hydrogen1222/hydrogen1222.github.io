#!/usr/bin/env python3
"""Helpers for a material-independent PBE/HSE06 -> SCDM -> Wannier90 workflow."""

from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

try:
    from pymatgen.core import Structure
    from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
    from pymatgen.symmetry.bandstructure import HighSymmKpath
except ImportError as error:
    raise SystemExit(
        "This workflow requires pymatgen. Install it with: pip install pymatgen"
    ) from error


SEED = "wannier90"


def read_eigenval(path: Path) -> dict:
    lines = path.read_text().splitlines()
    nelect, nkpoints, nbands = map(int, lines[5].split()[:3])
    index = 6
    kpoints: list[list[float]] = []
    energies: list[list[float]] = []
    for _ in range(nkpoints):
        while index < len(lines) and not lines[index].strip():
            index += 1
        fields = lines[index].split()
        kpoints.append([float(value) for value in fields[:3]])
        index += 1
        bands = []
        for _ in range(nbands):
            fields = lines[index].split()
            bands.append(float(fields[1]))
            index += 1
        energies.append(bands)
    return {
        "nelect": nelect,
        "nkpoints": nkpoints,
        "nbands": nbands,
        "nocc": nelect // 2,
        "kpoints": np.asarray(kpoints),
        "energies": np.asarray(energies),
    }


def read_w90_eig(path: Path) -> dict[int, np.ndarray]:
    values: dict[int, list[tuple[int, float]]] = {}
    for raw_line in path.read_text().splitlines():
        if not raw_line.strip():
            continue
        band, kpoint, energy = raw_line.split()[:3]
        values.setdefault(int(kpoint), []).append((int(band), float(energy)))
    return {
        kpoint: np.asarray([energy for _, energy in sorted(rows)])
        for kpoint, rows in values.items()
    }


def read_win_kpoints(path: Path) -> np.ndarray:
    points: list[list[float]] = []
    in_block = False
    for raw_line in path.read_text().splitlines():
        line = raw_line.strip().lower()
        if line == "begin kpoints":
            in_block = True
            continue
        if line == "end kpoints":
            break
        if in_block and raw_line.strip():
            points.append([float(value) for value in raw_line.split()[:3]])
    return np.asarray(points)


def read_geninterp(path: Path) -> dict[int, np.ndarray]:
    values: dict[int, list[float]] = {}
    for raw_line in path.read_text().splitlines():
        if not raw_line.strip() or raw_line.lstrip().startswith("#"):
            continue
        fields = raw_line.split()
        values.setdefault(int(fields[0]), []).append(float(fields[4]))
    return {index: np.sort(np.asarray(rows)) for index, rows in values.items()}


def write_geninterp_kpoints(path: Path, points: np.ndarray, comment: str) -> None:
    lines = [comment, "crystal", str(len(points))]
    lines.extend(
        f"{index:7d} {point[0]: .12f} {point[1]: .12f} {point[2]: .12f}"
        for index, point in enumerate(points, start=1)
    )
    path.write_text("\n".join(lines) + "\n")


def repair_mmn_headers(arguments: argparse.Namespace) -> None:
    """Repair VASP's adjacent I5 k-point indices without changing file size."""
    path = Path(arguments.mmn)
    rewritten = 0
    with path.open("r+b") as stream:
        comment = stream.readline()
        dimensions_line = stream.readline()
        try:
            num_bands, num_kpoints, num_neighbours = map(
                int, dimensions_line.split()[:3]
            )
        except ValueError as error:
            raise SystemExit(f"Cannot parse dimensions in {path}") from error

        num_blocks = num_kpoints * num_neighbours
        matrix_lines = num_bands * num_bands
        for block in range(1, num_blocks + 1):
            offset = stream.tell()
            raw = stream.readline()
            if not raw:
                raise SystemExit(f"Unexpected end of {path} at MMN block {block}")
            newline = b"\r\n" if raw.endswith(b"\r\n") else b"\n"
            body = raw[:-len(newline)]
            fields = body.split()
            try:
                if len(fields) == 5:
                    values = tuple(map(int, fields))
                elif len(body) == 25:
                    values = tuple(int(body[start:start + 5]) for start in range(0, 25, 5))
                else:
                    raise ValueError
            except ValueError as error:
                raise SystemExit(
                    f"Cannot parse MMN block header {block} at byte {offset} in {path}"
                ) from error

            normalized = " ".join(map(str, values)).encode()
            available = len(raw) - len(newline)
            if len(normalized) > available:
                raise SystemExit(
                    f"Cannot repair MMN block header {block} without changing file size"
                )
            replacement = normalized.ljust(available) + newline
            if replacement != raw:
                next_offset = stream.tell()
                stream.seek(offset)
                stream.write(replacement)
                stream.seek(next_offset)
                rewritten += 1

            for _ in range(matrix_lines):
                if not stream.readline():
                    raise SystemExit(
                        f"Unexpected end of {path} in MMN matrix block {block}"
                    )
        stream.flush()

    report = (
        f"MMN file: {path.resolve()}\n"
        f"Bands: {num_bands}\n"
        f"Full k points: {num_kpoints}\n"
        f"Neighbours per k point: {num_neighbours}\n"
        f"Block headers checked: {num_blocks}\n"
        f"Block headers rewritten: {rewritten}\n"
        "Repair method: length-preserving whitespace normalization; overlap values unchanged.\n"
    )
    if arguments.report:
        Path(arguments.report).write_text(report)
    print(report, end="")


def repair_amn_headers(arguments: argparse.Namespace) -> None:
    """Repair VASP's adjacent I5 AMN indices without changing projections."""
    path = Path(arguments.amn)
    rewritten = 0
    with path.open("r+b") as stream:
        stream.readline()
        dimensions_line = stream.readline()
        try:
            num_bands, num_kpoints, num_projections = map(
                int, dimensions_line.split()[:3]
            )
        except ValueError as error:
            raise SystemExit(f"Cannot parse dimensions in {path}") from error

        num_records = num_bands * num_kpoints * num_projections
        for record in range(1, num_records + 1):
            offset = stream.tell()
            raw = stream.readline()
            if not raw:
                raise SystemExit(f"Unexpected end of {path} at AMN record {record}")
            newline = b"\r\n" if raw.endswith(b"\r\n") else b"\n"
            body = raw[:-len(newline)]
            if len(body) < 15:
                raise SystemExit(f"Short AMN record {record} at byte {offset} in {path}")
            prefix = body[:15]
            fields = prefix.split()
            try:
                if len(fields) == 3:
                    values = tuple(map(int, fields))
                else:
                    values = tuple(int(prefix[start:start + 5]) for start in range(0, 15, 5))
            except ValueError as error:
                raise SystemExit(
                    f"Cannot parse AMN indices in record {record} at byte {offset}"
                ) from error

            normalized = " ".join(map(str, values)).encode()
            if len(normalized) > 15:
                raise SystemExit(
                    f"Cannot repair AMN record {record} without changing file size"
                )
            replacement = normalized.ljust(15) + body[15:] + newline
            if replacement != raw:
                next_offset = stream.tell()
                stream.seek(offset)
                stream.write(replacement)
                stream.seek(next_offset)
                rewritten += 1
        stream.flush()

    report = (
        f"AMN file: {path.resolve()}\n"
        f"Bands: {num_bands}\n"
        f"Full k points: {num_kpoints}\n"
        f"Projections: {num_projections}\n"
        f"Projection records checked: {num_records}\n"
        f"Projection headers rewritten: {rewritten}\n"
        "Repair method: length-preserving whitespace normalization; projection values unchanged.\n"
    )
    if arguments.report:
        Path(arguments.report).write_text(report)
    print(report, end="")


def parse_outcar_spin(path: Path) -> tuple[int, bool]:
    text = path.read_text(errors="replace")
    ispin_matches = re.findall(r"^\s*ISPIN\s*=\s*(\d+)", text, flags=re.MULTILINE)
    lsorbit_matches = re.findall(r"^\s*LSORBIT\s*=\s*([TF])", text, flags=re.MULTILINE)
    ispin = int(ispin_matches[-1]) if ispin_matches else 1
    lsorbit = lsorbit_matches[-1] == "T" if lsorbit_matches else False
    return ispin, lsorbit


def read_poscar_composition(path: Path) -> dict[str, int]:
    lines = path.read_text().splitlines()
    if len(lines) < 7:
        raise SystemExit(f"Invalid POSCAR: {path}")
    elements = lines[5].split()
    try:
        counts = [int(value) for value in lines[6].split()]
    except ValueError as error:
        raise SystemExit("The POSCAR must use VASP-5 element symbols on line 6") from error
    if len(elements) != len(counts):
        raise SystemExit("POSCAR element and count lines have different lengths")
    return dict(zip(elements, counts))


def read_automatic_kmesh(path: Path) -> tuple[str, tuple[int, int, int], tuple[float, float, float]]:
    lines = [line.strip() for line in path.read_text().splitlines() if line.strip()]
    if len(lines) < 4 or lines[1] != "0":
        raise SystemExit(
            "KPOINTS must be an automatic uniform mesh (second line = 0), not a line path."
        )
    if not lines[2].lower().startswith(("g", "m")):
        raise SystemExit("KPOINTS must use a Gamma or Monkhorst-Pack uniform mesh")
    scheme = "Gamma" if lines[2].lower().startswith("g") else "Monkhorst-Pack"
    try:
        mesh = tuple(int(value) for value in lines[3].split()[:3])
        shift = tuple(float(value) for value in lines[4].split()[:3]) if len(lines) > 4 else (0.0, 0.0, 0.0)
    except ValueError as error:
        raise SystemExit(f"Cannot parse automatic mesh from {path}") from error
    if len(mesh) != 3 or len(shift) != 3 or min(mesh) < 1:
        raise SystemExit(f"Invalid automatic mesh in {path}")
    return scheme, mesh, shift


def write_kpoints(arguments: argparse.Namespace) -> None:
    scheme, mesh, shift = read_automatic_kmesh(Path(arguments.source))
    capped = tuple(min(value, arguments.max_mesh) for value in mesh)
    text = (
        f"Wannier construction mesh; source mesh was {mesh[0]} {mesh[1]} {mesh[2]}\n"
        "0\n"
        f"{scheme}\n"
        f"{capped[0]} {capped[1]} {capped[2]}\n"
        f"{shift[0]:.10g} {shift[1]:.10g} {shift[2]:.10g}\n"
    )
    Path(arguments.output).write_text(text)
    print(*capped)


def equivalent_kpoints(first: np.ndarray, second: np.ndarray, tolerance: float = 1.0e-8) -> bool:
    difference = np.asarray(first) - np.asarray(second)
    difference -= np.rint(difference)
    return bool(np.linalg.norm(difference) < tolerance)


def formula_and_spacegroup(poscar: Path) -> tuple[str, str]:
    structure = Structure.from_file(poscar)
    formula = structure.composition.reduced_formula
    analyzer = SpacegroupAnalyzer(structure, symprec=1.0e-4, angle_tolerance=5)
    spacegroup = f"{analyzer.get_space_group_symbol()} (No. {analyzer.get_space_group_number()})"
    return formula, spacegroup


def normalize_label(label: str) -> str:
    cleaned = label.strip().strip("#!").replace("\\Gamma", "G")
    if cleaned.upper() in {"GAMMA", "Γ"}:
        return "G"
    return cleaned


def automatic_kpath(poscar: Path) -> list[tuple[str, np.ndarray, str, np.ndarray]]:
    structure = Structure.from_file(poscar)
    kpath = HighSymmKpath(structure, path_type="setyawan_curtarolo", symprec=1.0e-4)
    same_primitive = (
        len(structure) == len(kpath.prim)
        and np.allclose(structure.lattice.matrix, kpath.prim.lattice.matrix,
                        atol=1.0e-5, rtol=1.0e-7)
    )
    if not same_primitive:
        raise SystemExit(
            "Automatic Setyawan-Curtarolo paths require the input POSCAR to be "
            "the standardized primitive cell. Prepare the PBE/HSE06 calculation "
            "with a standardized primitive POSCAR before using this workflow."
        )
    points = kpath.kpath["kpoints"]
    segments: list[tuple[str, np.ndarray, str, np.ndarray]] = []
    for branch in kpath.kpath["path"]:
        for start, end in zip(branch[:-1], branch[1:]):
            segments.append(
                (normalize_label(start), np.asarray(points[start]),
                 normalize_label(end), np.asarray(points[end]))
            )
    return segments


def format_path(segments: list[tuple[str, np.ndarray, str, np.ndarray]]) -> str:
    branches: list[list[str]] = []
    for start, _, end, _ in segments:
        if not branches or branches[-1][-1] != start:
            branches.append([start, end])
        else:
            branches[-1].append(end)
    return " | ".join("-".join("Gamma" if label == "G" else label for label in branch)
                      for branch in branches)


def path_info(arguments: argparse.Namespace) -> None:
    segments = automatic_kpath(Path(arguments.poscar))
    source = "pymatgen Setyawan-Curtarolo convention"
    print(f"{format_path(segments)} [{source}]")


def identify_functional(outcar_text: str) -> str:
    lhfc_matches = re.findall(
        r"^\s*LHFCALC\s*=\s*([TF])", outcar_text, flags=re.MULTILINE
    )
    gga_matches = re.findall(r"^\s*GGA\s*=\s*(\S+)", outcar_text, flags=re.MULTILINE)
    lhfc = lhfc_matches[-1] == "T" if lhfc_matches else False
    gga = gga_matches[-1].upper() if gga_matches else ""
    if not lhfc and gga == "PE":
        return "PBE"
    if lhfc and gga == "PE":
        aexx_matches = re.findall(
            r"^\s*AEXX\s*=\s*([-+0-9.Ee]+)", outcar_text, flags=re.MULTILINE
        )
        screen_matches = re.findall(
            r"^\s*HFSCREEN\s*=\s*([-+0-9.Ee]+)", outcar_text, flags=re.MULTILINE
        )
        if (
            aexx_matches
            and screen_matches
            and abs(float(aexx_matches[-1]) - 0.25) < 1.0e-8
            and abs(float(screen_matches[-1]) - 0.20) < 1.0e-8
        ):
            return "HSE06"
    raise SystemExit(
        "This workflow currently accepts PBE (GGA=PE, LHFCALC=F) or HSE06 "
        "(GGA=PE, LHFCALC=T, AEXX=0.25, HFSCREEN=0.20)."
    )


def inspect_vasp(arguments: argparse.Namespace) -> None:
    source_dir = Path(arguments.source_dir).resolve()
    required = ["POSCAR", "POTCAR", "KPOINTS", "WAVECAR", "EIGENVAL", "OUTCAR"]
    missing = [
        name for name in required
        if not (source_dir / name).is_file() or (source_dir / name).stat().st_size == 0
    ]
    if missing:
        raise SystemExit("Missing PBE/HSE06 files: " + ", ".join(missing))
    data = read_eigenval(source_dir / "EIGENVAL")
    ispin, lsorbit = parse_outcar_spin(source_dir / "OUTCAR")
    _, mesh, _ = read_automatic_kmesh(source_dir / "KPOINTS")
    formula, spacegroup = formula_and_spacegroup(source_dir / "POSCAR")
    outcar_text = (source_dir / "OUTCAR").read_text(errors="replace")
    if "General timing and accounting" not in outcar_text:
        raise SystemExit("The input OUTCAR does not show a normally completed VASP run")
    nsw_matches = re.findall(r"^\s*NSW\s*=\s*(\d+)", outcar_text, flags=re.MULTILINE)
    if not nsw_matches or int(nsw_matches[-1]) != 0:
        raise SystemExit(
            "The input must be a static calculation with NSW=0. After structural "
            "relaxation, run a separate PBE/HSE06 single point using the final structure."
        )
    ialgo_matches = re.findall(
        r"^\s*IALGO\s*=\s*(\d+)", outcar_text, flags=re.MULTILINE
    )
    if ialgo_matches and int(ialgo_matches[-1]) == 2:
        raise SystemExit(
            "The input appears to be an ALGO=None wavefunction-export run, not a "
            "self-consistent PBE/HSE06 source calculation. Use the original converged directory."
        )
    functional = identify_functional(outcar_text)
    if ispin != 1 or lsorbit:
        raise SystemExit(
            "This workflow currently supports only ISPIN=1 and LSORBIT=.FALSE. "
            f"Detected ISPIN={ispin}, LSORBIT={lsorbit}."
        )
    if data["nelect"] % 2 or data["nbands"] <= data["nocc"]:
        raise SystemExit("The PBE/HSE06 result is not a closed-shell insulator with empty bands")
    energies = data["energies"]
    nocc = data["nocc"]
    vbm_index = int(np.argmax(energies[:, nocc - 1]))
    cbm_index = int(np.argmin(energies[:, nocc]))
    vbm = float(energies[vbm_index, nocc - 1])
    cbm = float(energies[cbm_index, nocc])
    if cbm <= vbm:
        raise SystemExit(f"The sampled {functional} gap is {cbm - vbm:.6f} eV; this is not an insulator")
    frozen_guess = float(np.max(energies[:, nocc]) + 0.10)
    max_frozen = int(np.max(np.sum(energies <= frozen_guess, axis=1)))
    suggested_num_wann = min(data["nbands"], max(nocc + 6, max_frozen + 2))
    direct = equivalent_kpoints(data["kpoints"][vbm_index], data["kpoints"][cbm_index])
    report = (
        f"Functional: {functional}\n"
        f"Formula: {formula}\n"
        f"Space group: {spacegroup}\n"
        f"Sampled {functional} VBM: {vbm:.9f} eV, band {nocc}, "
        f"k={tuple(map(float, data['kpoints'][vbm_index]))}\n"
        f"Sampled {functional} CBM: {cbm:.9f} eV, band {nocc + 1}, "
        f"k={tuple(map(float, data['kpoints'][cbm_index]))}\n"
        f"Sampled {functional} gap: {cbm - vbm:.9f} eV\n"
        f"Direct on the input mesh: {direct}\n"
        "Note: this classification is limited to the sampled uniform k mesh; "
        "the dense Wannier scan checks points between it.\n"
    )
    if arguments.report:
        Path(arguments.report).write_text(report)
    print(data["nelect"], data["nkpoints"], data["nbands"], nocc, ispin,
          suggested_num_wann, functional, *mesh)


def write_incar(arguments: argparse.Namespace) -> None:
    outcar_text = Path(arguments.source_outcar).read_text(errors="replace")
    encut_matches = re.findall(
        r"^\s*ENCUT\s*=\s*([-+0-9.Ee]+)\s+eV", outcar_text, flags=re.MULTILINE
    )
    if not encut_matches:
        raise SystemExit(f"Cannot determine ENCUT from {arguments.source_outcar}")
    encut = float(encut_matches[-1])
    precision_matches = re.findall(
        r"^\s*PREC\s*=\s*(\S+)", outcar_text, flags=re.MULTILINE
    )
    precision = "Accurate" if precision_matches and precision_matches[-1].lower().startswith("acc") else "Normal"
    lasph_matches = re.findall(
        r"^\s*LASPH\s*=\s*\.?([TF])", outcar_text, flags=re.MULTILINE
    )
    addgrid_matches = re.findall(
        r"^\s*ADDGRID\s*=\s*\.?([TF])", outcar_text, flags=re.MULTILINE
    )
    lasph = lasph_matches[-1] if lasph_matches else "F"
    addgrid = addgrid_matches[-1] if addgrid_matches else "F"
    if arguments.mode == "reuse-wavecar":
        electronic_control = """ISTART = 1
ALGO  = None
NELM  = 1
LDIAG = .FALSE.
"""
    else:
        fine_grid_matches = re.findall(
            r"dimension x,y,z\s+NGXF=\s*(\d+)\s+NGYF=\s*(\d+)\s+NGZF=\s*(\d+)",
            outcar_text,
        )
        if not fine_grid_matches:
            raise SystemExit(
                f"Cannot determine the CHGCAR FFT grid from {arguments.source_outcar}"
            )
        ngxf, ngyf, ngzf = fine_grid_matches[-1]
        electronic_control = """ISTART = 0
ICHARG = 11
ALGO   = Normal
NELM   = 80
EDIFF  = 1E-8
LDIAG  = .TRUE.
""" + f"NGXF = {ngxf}\nNGYF = {ngyf}\nNGZF = {ngzf}\n"
    text = f"""SYSTEM = PBE/HSE06 wavefunction -> SCDM/Wannier90 export

{electronic_control.rstrip()}
ISPIN  = 1
NBANDS = {arguments.post_nbands}
ENCUT  = {encut:.10g}
PREC   = {precision}
LASPH  = .{lasph}.
ADDGRID = .{addgrid}.

LREAL = .FALSE.
NSW   = 0
IBRION = -1

LWAVE  = .FALSE.
LCHARG = .FALSE.

NUM_WANN = {arguments.num_wann}
LSCDM = .TRUE.
CUTOFF_TYPE  = num_wann
CUTOFF_SIGMA = 0.1

LWANNIER90 = .TRUE.

WANNIER90_WIN = "
dis_num_iter = 0
num_iter = 0
"
"""
    Path(arguments.output).write_text(text)


def prepare_win(arguments: argparse.Namespace) -> None:
    setup_win = Path(arguments.setup_win)
    text = setup_win.read_text()
    marker = "# This part was generated automatically by VASP"
    if marker not in text:
        raise SystemExit(f"Could not find the VASP-generated section in {setup_win}")
    generated = marker + text.split(marker, 1)[1]

    eig = read_w90_eig(Path(arguments.eig))
    exported_nbands = len(next(iter(eig.values())))
    if exported_nbands != arguments.physical_nbands:
        raise SystemExit(
            f"VASP exported {exported_nbands} bands but the input contains "
            f"{arguments.physical_nbands}. Use an MPI rank count that divides input NBANDS."
        )
    physical = np.asarray([rows[: arguments.physical_nbands] for _, rows in sorted(eig.items())])
    if physical.shape[1] != arguments.physical_nbands:
        raise SystemExit("The exported EIG file contains fewer bands than the input reference")

    vbm = float(np.max(physical[:, arguments.nocc - 1]))
    cbm = float(np.min(physical[:, arguments.nocc]))
    outer_min = float(np.min(physical) - 0.50)
    outer_max = float(np.max(physical) + 0.10)
    frozen_max = float(np.max(physical[:, arguments.nocc]) + 0.10)
    frozen_counts = np.sum((physical >= outer_min) & (physical <= frozen_max), axis=1)
    if int(np.max(frozen_counts)) > arguments.num_wann:
        frozen_max = float(np.max(physical[:, arguments.nocc]) + 1.0e-5)
        frozen_counts = np.sum((physical >= outer_min) & (physical <= frozen_max), axis=1)
    if int(np.max(frozen_counts)) > arguments.num_wann:
        raise SystemExit(
            "The automatically selected frozen window contains more states than NUM_WANN. "
            "Increase NUM_WANN and rerun."
        )

    formula, spacegroup = formula_and_spacegroup(Path(arguments.poscar))
    segments = automatic_kpath(Path(arguments.poscar))
    path_source = "pymatgen Setyawan-Curtarolo convention"
    path_string = format_path(segments)

    controls = f"""! Automatically prepared by the material-independent PBE/HSE06-Wannier90 workflow.
! The outer window is limited to the physical input bands.
dis_win_min = {outer_min:.8f}
dis_win_max = {outer_max:.8f}
dis_froz_min = {outer_min:.8f}
dis_froz_max = {frozen_max:.8f}
dis_num_iter = 500
dis_conv_tol = 2.5e-6
dis_conv_window = 5

num_iter = 500
conv_tol = 1.0e-8
conv_window = 10

bands_plot = true
bands_num_points = 80
bands_plot_format = gnuplot
write_hr = true

geninterp = true
geninterp_single_file = true

"""
    path_lines = ["", "begin kpoint_path"]
    for start, start_point, end, end_point in segments:
        path_lines.append(
            f"{start:<8s} {start_point[0]: .10f} {start_point[1]: .10f} {start_point[2]: .10f}   "
            f"{end:<8s} {end_point[0]: .10f} {end_point[1]: .10f} {end_point[2]: .10f}"
        )
    path_lines.append("end kpoint_path")
    path_block = "\n".join(path_lines) + "\n"
    Path(arguments.output_win).write_text(controls + generated.rstrip() + path_block)

    kpoints = read_win_kpoints(Path(arguments.output_win))
    vbm_kindex = int(np.argmax(physical[:, arguments.nocc - 1])) + 1
    cbm_kindex = int(np.argmin(physical[:, arguments.nocc])) + 1
    metadata = {
        "physical_nbands": arguments.physical_nbands,
        "post_nbands": exported_nbands,
        "num_wann": arguments.num_wann,
        "nocc": arguments.nocc,
        "nkpoints_full": int(len(physical)),
        "outer_min_eV": outer_min,
        "outer_max_eV": outer_max,
        "frozen_min_eV": outer_min,
        "frozen_max_eV": frozen_max,
        "max_frozen_states": int(np.max(frozen_counts)),
        "vbm_eV": vbm,
        "cbm_eV": cbm,
        "gap_eV": cbm - vbm,
        "vbm_kindex": vbm_kindex,
        "cbm_kindex": cbm_kindex,
        "vbm_k_frac": kpoints[vbm_kindex - 1].tolist(),
        "cbm_k_frac": kpoints[cbm_kindex - 1].tolist(),
        "formula": formula,
        "functional": arguments.functional,
        "spacegroup": spacegroup,
        "path": path_string,
        "path_source": path_source,
        "construction_mode": arguments.construction_mode,
        "construction_mesh": arguments.construction_mesh,
    }
    Path(arguments.metadata).write_text(json.dumps(metadata, indent=2) + "\n")
    print(f"Outer window:  [{outer_min:.6f}, {outer_max:.6f}] eV")
    print(f"Frozen window: [{outer_min:.6f}, {frozen_max:.6f}] eV")
    print(f"Reference gap: {cbm - vbm:.9f} eV")
    print(f"Band path: {path_string}")
    print(f"Path source: {path_source}")


def prepare_validation(arguments: argparse.Namespace) -> None:
    points = read_win_kpoints(Path(arguments.win))
    write_geninterp_kpoints(
        Path(arguments.output), points,
        "Wannier construction mesh for interpolation validation",
    )
    print(f"Prepared validation input with {len(points)} k points")


def prepare_source_validation(arguments: argparse.Namespace) -> None:
    data = read_eigenval(Path(arguments.eigenval))
    write_geninterp_kpoints(
        Path(arguments.output), data["kpoints"],
        "Original source-mesh k points for independent interpolation validation",
    )
    print(f"Prepared source validation with {data['nkpoints']} irreducible k points")


def validate(arguments: argparse.Namespace) -> None:
    metadata = json.loads(Path(arguments.metadata).read_text())
    reference = read_w90_eig(Path(arguments.reference))
    interpolated = read_geninterp(Path(arguments.interpolated))
    common = sorted(set(reference) & set(interpolated))
    if len(common) != metadata["nkpoints_full"]:
        raise SystemExit(
            f"Expected {metadata['nkpoints_full']} validation k points, found {len(common)}"
        )
    count = metadata["nocc"] + 1
    errors = np.asarray(
        [interpolated[index][:count] - reference[index][:count] for index in common]
    )
    edge_start = max(0, metadata["nocc"] - 3)
    edge_errors = errors[:, edge_start:count]
    max_all = float(np.max(np.abs(errors)))
    max_edge = float(np.max(np.abs(edge_errors)))

    vbm_index = metadata["vbm_kindex"]
    reference_gap = reference[vbm_index][metadata["nocc"]] - reference[vbm_index][metadata["nocc"] - 1]
    interpolated_gap = (
        interpolated[vbm_index][metadata["nocc"]]
        - interpolated[vbm_index][metadata["nocc"] - 1]
    )
    report = (
        f"Validated k points: {len(common)}\n"
        f"Maximum absolute error, frozen bands 1-{count}: {max_all:.6e} eV\n"
        f"Maximum absolute error, band-edge group: {max_edge:.6e} eV\n"
        f"Reference direct gap at VBM k point: {reference_gap:.9f} eV\n"
        f"Wannier direct gap at VBM k point:   {interpolated_gap:.9f} eV\n"
        f"Gap difference: {interpolated_gap - reference_gap:+.6e} eV\n"
    )
    Path(arguments.report).write_text(report)
    print(report, end="")
    if max_edge > arguments.tolerance:
        raise SystemExit(
            f"Band-edge interpolation error {max_edge:.3e} eV exceeds "
            f"the tolerance {arguments.tolerance:.3e} eV"
        )


def validate_source(arguments: argparse.Namespace) -> None:
    metadata = json.loads(Path(arguments.metadata).read_text())
    reference = read_eigenval(Path(arguments.reference_eigenval))
    interpolated = read_geninterp(Path(arguments.interpolated))
    expected = reference["nkpoints"]
    if len(interpolated) != expected:
        raise SystemExit(f"Expected {expected} source k points, found {len(interpolated)}")
    count = metadata["nocc"] + 1
    errors = np.asarray([
        interpolated[index][:count] - reference["energies"][index - 1, :count]
        for index in range(1, expected + 1)
    ])
    max_all = float(np.max(np.abs(errors)))
    nocc = metadata["nocc"]
    reference_valence = reference["energies"][:, nocc - 1]
    reference_conduction = reference["energies"][:, nocc]
    interpolated_valence = np.asarray([
        interpolated[index][nocc - 1] for index in range(1, expected + 1)
    ])
    interpolated_conduction = np.asarray([
        interpolated[index][nocc] for index in range(1, expected + 1)
    ])

    reference_vbm_index = int(np.argmax(reference_valence))
    reference_cbm_index = int(np.argmin(reference_conduction))
    interpolated_vbm_index = int(np.argmax(interpolated_valence))
    interpolated_cbm_index = int(np.argmin(interpolated_conduction))
    reference_vbm = float(reference_valence[reference_vbm_index])
    reference_cbm = float(reference_conduction[reference_cbm_index])
    interpolated_vbm = float(interpolated_valence[interpolated_vbm_index])
    interpolated_cbm = float(interpolated_conduction[interpolated_cbm_index])
    reference_gap = reference_cbm - reference_vbm
    interpolated_gap = interpolated_cbm - interpolated_vbm
    vbm_difference = interpolated_vbm - reference_vbm
    cbm_difference = interpolated_cbm - reference_cbm
    gap_difference = interpolated_gap - reference_gap
    edge_metric = max(
        abs(vbm_difference), abs(cbm_difference), abs(gap_difference)
    )

    reference_vbm_k = tuple(map(float, reference["kpoints"][reference_vbm_index]))
    reference_cbm_k = tuple(map(float, reference["kpoints"][reference_cbm_index]))
    interpolated_vbm_k = tuple(map(float, reference["kpoints"][interpolated_vbm_index]))
    interpolated_cbm_k = tuple(map(float, reference["kpoints"][interpolated_cbm_index]))
    report = (
        f"Validated source irreducible k points: {expected}\n"
        f"Maximum absolute error, bands 1-{count} (informational): {max_all:.6e} eV\n"
        f"Source VBM:  {reference_vbm:.9f} eV at k={reference_vbm_k}\n"
        f"Wannier VBM on same mesh: {interpolated_vbm:.9f} eV at k={interpolated_vbm_k}\n"
        f"VBM difference: {vbm_difference:+.6e} eV\n"
        f"Source CBM:  {reference_cbm:.9f} eV at k={reference_cbm_k}\n"
        f"Wannier CBM on same mesh: {interpolated_cbm:.9f} eV at k={interpolated_cbm_k}\n"
        f"CBM difference: {cbm_difference:+.6e} eV\n"
        f"Source fundamental gap:  {reference_gap:.9f} eV\n"
        f"Wannier fundamental gap on same mesh: {interpolated_gap:.9f} eV\n"
        f"Gap difference: {gap_difference:+.6e} eV\n"
        f"Maximum VBM/CBM/gap difference: {edge_metric:.6e} eV\n"
        f"Allowed VBM/CBM/gap difference: {arguments.tolerance:.6e} eV\n"
    )
    Path(arguments.report).write_text(report)
    print(report, end="")
    if edge_metric > arguments.tolerance:
        raise SystemExit(
            f"Source-mesh VBM/CBM/gap error {edge_metric:.3e} eV exceeds "
            f"the tolerance {arguments.tolerance:.3e} eV. Increase WANNIER_MESH_MAX."
        )


def prepare_scan(arguments: argparse.Namespace) -> None:
    mesh = arguments.mesh
    points = np.asarray(
        [(i / mesh, j / mesh, k / mesh)
         for i in range(mesh) for j in range(mesh) for k in range(mesh)]
    )
    write_geninterp_kpoints(
        Path(arguments.output), points,
        f"Uniform {mesh}x{mesh}x{mesh} grid for the Wannier band-gap scan",
    )
    print(f"Prepared {mesh}x{mesh}x{mesh} scan with {len(points)} k points")


def read_input_kpoints(path: Path) -> dict[int, tuple[float, float, float]]:
    lines = path.read_text().splitlines()[3:]
    return {
        int(fields[0]): tuple(float(value) for value in fields[1:4])
        for fields in (line.split() for line in lines)
    }


def scan_report(arguments: argparse.Namespace) -> None:
    metadata = json.loads(Path(arguments.metadata).read_text())
    points = read_input_kpoints(Path(arguments.kpoints))
    energies = read_geninterp(Path(arguments.data))
    nocc = metadata["nocc"]
    vbm_index = max(energies, key=lambda index: energies[index][nocc - 1])
    cbm_index = min(energies, key=lambda index: energies[index][nocc])
    vbm = float(energies[vbm_index][nocc - 1])
    cbm = float(energies[cbm_index][nocc])
    direct = equivalent_kpoints(points[vbm_index], points[cbm_index])
    metadata["dense_scan"] = {
        "number_of_kpoints": len(points),
        "vbm_eV": vbm,
        "cbm_eV": cbm,
        "gap_eV": cbm - vbm,
        "vbm_k_frac": list(points[vbm_index]),
        "cbm_k_frac": list(points[cbm_index]),
        "direct": direct,
    }
    Path(arguments.metadata).write_text(json.dumps(metadata, indent=2) + "\n")
    report = (
        f"VBM: {vbm:.9f} eV at fractional k={points[vbm_index]}\n"
        f"CBM: {cbm:.9f} eV at fractional k={points[cbm_index]}\n"
        f"Uniform-grid gap: {cbm - vbm:.9f} eV\n"
        f"Direct on this grid: {direct}\n"
    )
    Path(arguments.report).write_text(report)
    print(report, end="")


def source_scan_report(arguments: argparse.Namespace) -> None:
    metadata = json.loads(Path(arguments.metadata).read_text())
    source = read_eigenval(Path(arguments.eigenval))
    nocc = metadata["nocc"]
    vbm_index = int(np.argmax(source["energies"][:, nocc - 1]))
    cbm_index = int(np.argmin(source["energies"][:, nocc]))
    vbm = float(source["energies"][vbm_index, nocc - 1])
    cbm = float(source["energies"][cbm_index, nocc])
    vbm_k = tuple(map(float, source["kpoints"][vbm_index]))
    cbm_k = tuple(map(float, source["kpoints"][cbm_index]))
    direct = equivalent_kpoints(vbm_k, cbm_k)
    metadata["dense_scan"] = {
        "number_of_kpoints": source["nkpoints"],
        "mesh": arguments.mesh,
        "source": "original dense VASP EIGENVAL",
        "vbm_eV": vbm,
        "cbm_eV": cbm,
        "gap_eV": cbm - vbm,
        "vbm_k_frac": list(vbm_k),
        "cbm_k_frac": list(cbm_k),
        "direct": direct,
    }
    Path(arguments.metadata).write_text(json.dumps(metadata, indent=2) + "\n")
    report = (
        f"Dense source mesh: {arguments.mesh}\n"
        f"Irreducible source k points: {source['nkpoints']}\n"
        f"VBM: {vbm:.9f} eV at fractional k={vbm_k}\n"
        f"CBM: {cbm:.9f} eV at fractional k={cbm_k}\n"
        f"Source-grid gap: {cbm - vbm:.9f} eV\n"
        f"Direct on this grid: {direct}\n"
        "A separate coarser Wannier scan was skipped because the explicitly retained "
        "source mesh is at least as dense in every direction.\n"
    )
    Path(arguments.report).write_text(report)
    print(report, end="")


def read_band_blocks(path: Path) -> tuple[np.ndarray, np.ndarray]:
    blocks: list[list[tuple[float, float]]] = []
    current: list[tuple[float, float]] = []
    for raw_line in path.read_text().splitlines():
        if not raw_line.strip():
            if current:
                blocks.append(current)
                current = []
            continue
        distance, energy = map(float, raw_line.split()[:2])
        current.append((distance, energy))
    if current:
        blocks.append(current)
    if not blocks or len({len(block) for block in blocks}) != 1:
        raise SystemExit("Unexpected Wannier90 band-data layout")
    distances = np.asarray([row[0] for row in blocks[0]])
    energies = np.asarray([[row[1] for row in block] for block in blocks])
    return distances, energies


def read_labels(path: Path) -> tuple[list[float], list[str]]:
    grouped: list[tuple[float, list[str]]] = []
    for raw_line in path.read_text().splitlines():
        fields = raw_line.split()
        label, position = fields[0], float(fields[2])
        if grouped and abs(grouped[-1][0] - position) < 1.0e-9:
            grouped[-1][1].append(label)
        else:
            grouped.append((position, [label]))
    replacements = {"G": r"$\Gamma$", "GAMMA": r"$\Gamma$"}
    positions = [position for position, _ in grouped]
    labels = [
        "|".join(replacements.get(label, rf"${label}$") for label in names)
        for _, names in grouped
    ]
    return positions, labels


def plot_bands(arguments: argparse.Namespace) -> None:
    metadata = json.loads(Path(arguments.metadata).read_text())
    distances, energies_absolute = read_band_blocks(Path(arguments.band_data))
    positions, labels = read_labels(Path(arguments.labels))
    gap_reference = metadata.get("dense_scan", metadata)
    vbm = gap_reference["vbm_eV"]
    gap = gap_reference["gap_eV"]
    nocc = metadata["nocc"]
    energies = energies_absolute - vbm
    upper = metadata["frozen_max_eV"] - vbm
    lower = arguments.emin

    with Path(arguments.csv).open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["path_distance_A^-1", "wannier_band", "energy_minus_vbm_eV"])
        for band_index, band in enumerate(energies, start=1):
            writer.writerows(
                (f"{distance:.10f}", band_index, f"{energy:.10f}")
                for distance, energy in zip(distances, band)
            )

    plt.rcParams.update({
        "font.size": 10,
        "axes.linewidth": 0.8,
        "font.family": "DejaVu Sans",
        "mathtext.fontset": "dejavusans",
    })
    figure, axes = plt.subplots(1, 2, figsize=(11.2, 5.2), sharex=True)
    valence_color, conduction_color = "#315B9A", "#B3473D"

    def style_axis(axis, limits: tuple[float, float]) -> None:
        for position in positions:
            axis.axvline(position, color="0.82", linewidth=0.65, zorder=0)
        axis.axhline(0.0, color="0.25", linewidth=0.8, linestyle="--", zorder=1)
        axis.set_xlim(positions[0], positions[-1])
        axis.set_ylim(*limits)
        axis.set_xticks(positions, labels)
        axis.tick_params(axis="x", length=0)
        axis.tick_params(direction="in", top=True, right=True)
        axis.set_ylabel(r"$E-E_\mathrm{VBM}$ (eV)")

    for axis in axes:
        axis.axhspan(0.0, gap, color="#E9F2E4", alpha=0.55, zorder=-2)
        for index, band in enumerate(energies):
            color = valence_color if index < nocc else conduction_color
            axis.plot(distances, band, color=color, linewidth=0.78, alpha=0.96)

    style_axis(axes[0], (lower, upper))
    style_axis(axes[1], (-1.25, upper))
    axes[0].set_title("Valence and low-conduction bands")
    axes[1].set_title("Band-edge region")

    direct_reference = equivalent_kpoints(
        gap_reference["vbm_k_frac"], gap_reference["cbm_k_frac"]
    )
    is_gamma_direct = (
        direct_reference
        and np.linalg.norm(np.mod(gap_reference["vbm_k_frac"], 1.0)) < 1.0e-8
        and np.linalg.norm(np.mod(gap_reference["cbm_k_frac"], 1.0)) < 1.0e-8
    )
    gamma_positions = [
        position for position, label in zip(positions, labels) if r"\Gamma" in label
    ]
    if is_gamma_direct and gamma_positions:
        gamma_x = gamma_positions[0]
        axes[1].scatter([gamma_x, gamma_x], [0.0, gap],
                        color=[valence_color, conduction_color], s=24, zorder=5)
        direction = 1.0 if gamma_x < 0.8 * positions[-1] else -1.0
        arrow_x = gamma_x + direction * 0.018 * (positions[-1] - positions[0])
        axes[1].annotate(
            "", xy=(arrow_x, gap), xytext=(arrow_x, 0.0),
            arrowprops={"arrowstyle": "<->", "lw": 0.9, "color": "0.25"},
        )
        axes[1].text(
            gamma_x + direction * 0.065 * (positions[-1] - positions[0]), gap / 2,
            rf"$E_g={gap:.3f}$ eV" + "\n" + r"$\Gamma\!\rightarrow\!\Gamma$",
            ha="left" if direction > 0 else "right", va="center",
        )
    else:
        character = "direct" if direct_reference else "indirect"
        axes[1].text(
            0.05, 0.88, rf"$E_g={gap:.3f}$ eV" + "\n" + character,
            transform=axes[1].transAxes, ha="left", va="top",
        )

    formula_title = re.sub(r"(\d+)", r"$_{\1}$", metadata["formula"])
    figure.suptitle(
        f"{formula_title} {metadata['functional']} band structure — Wannier90 interpolation",
        y=0.99,
    )
    figure.tight_layout(rect=(0, 0, 1, 0.965))
    figure.savefig(arguments.png, dpi=300, bbox_inches="tight")
    figure.savefig(arguments.pdf, bbox_inches="tight")
    print(f"Energy zero (VBM): {vbm:.9f} eV")
    print(f"Wrote {arguments.png}, {arguments.pdf}, and {arguments.csv}")


def write_results(arguments: argparse.Namespace) -> None:
    metadata = json.loads(Path(arguments.metadata).read_text())
    mesh_gap = Path(arguments.mesh_gap).read_text().strip()
    validation = Path(arguments.validation).read_text().strip()
    scan = Path(arguments.scan).read_text().strip()
    source_validation = ""
    if arguments.source_validation:
        source_text = Path(arguments.source_validation).read_text().strip()
        source_validation = f"""

## Cross-validation on the original dense source mesh

```text
{source_text}
```
"""
    prefix = f"{metadata['functional']}_Wannier90"
    text = f"""# {metadata['formula']} {metadata['functional']}-Wannier90 workflow result

- Space group: {metadata['spacegroup']}
- Occupied bands: {metadata['nocc']}
- Physical input bands: {metadata['physical_nbands']}
- Wannier functions: {metadata['num_wann']}
- Outer window: [{metadata['outer_min_eV']:.6f}, {metadata['outer_max_eV']:.6f}] eV
- Frozen window: [{metadata['frozen_min_eV']:.6f}, {metadata['frozen_max_eV']:.6f}] eV
- Input-mesh/Wannier gap: {metadata['gap_eV']:.9f} eV
- Path: {metadata['path']}
- Path source: {metadata['path_source']}
- Wannier construction mode: {metadata['construction_mode']}
- Wannier construction mesh: {metadata['construction_mesh']}

## Gap on the input PBE/HSE06 mesh

```text
{mesh_gap}
```

## Validation on the Wannier construction mesh

```text
{validation}
```
{source_validation}

## Dense full-zone scan

```text
{scan}
```

## Final files

- `{prefix}_bands.png`
- `{prefix}_bands.pdf`
- `{prefix}_bands.csv`
- `wannier90_hr.dat`
- `wannier90.wout.localisation`
"""
    Path(arguments.output).write_text(text)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)

    command = subparsers.add_parser("inspect")
    command.add_argument("--source-dir", required=True)
    command.add_argument("--report")
    command.set_defaults(func=inspect_vasp)

    command = subparsers.add_parser("path-info")
    command.add_argument("--poscar", required=True)
    command.set_defaults(func=path_info)

    command = subparsers.add_parser("write-kpoints")
    command.add_argument("--source", required=True)
    command.add_argument("--max-mesh", type=int, required=True)
    command.add_argument("--output", required=True)
    command.set_defaults(func=write_kpoints)

    command = subparsers.add_parser("repair-mmn")
    command.add_argument("--mmn", required=True)
    command.add_argument("--report")
    command.set_defaults(func=repair_mmn_headers)

    command = subparsers.add_parser("repair-amn")
    command.add_argument("--amn", required=True)
    command.add_argument("--report")
    command.set_defaults(func=repair_amn_headers)

    command = subparsers.add_parser("write-incar")
    command.add_argument("--source-outcar", required=True)
    command.add_argument("--post-nbands", type=int, required=True)
    command.add_argument("--num-wann", type=int, required=True)
    command.add_argument(
        "--mode", choices=("reuse-wavecar", "pbe-fixed-density"), required=True
    )
    command.add_argument("--output", required=True)
    command.set_defaults(func=write_incar)

    command = subparsers.add_parser("prepare-win")
    command.add_argument("--setup-win", required=True)
    command.add_argument("--eig", required=True)
    command.add_argument("--physical-nbands", type=int, required=True)
    command.add_argument("--nocc", type=int, required=True)
    command.add_argument("--num-wann", type=int, required=True)
    command.add_argument("--functional", choices=("PBE", "HSE06"), required=True)
    command.add_argument("--construction-mode", required=True)
    command.add_argument("--construction-mesh", required=True)
    command.add_argument("--poscar", required=True)
    command.add_argument("--output-win", required=True)
    command.add_argument("--metadata", required=True)
    command.set_defaults(func=prepare_win)

    command = subparsers.add_parser("prepare-validation")
    command.add_argument("--win", required=True)
    command.add_argument("--output", required=True)
    command.set_defaults(func=prepare_validation)

    command = subparsers.add_parser("prepare-source-validation")
    command.add_argument("--eigenval", required=True)
    command.add_argument("--output", required=True)
    command.set_defaults(func=prepare_source_validation)

    command = subparsers.add_parser("validate")
    command.add_argument("--metadata", required=True)
    command.add_argument("--reference", required=True)
    command.add_argument("--interpolated", required=True)
    command.add_argument("--report", required=True)
    command.add_argument("--tolerance", type=float, default=1.0e-5)
    command.set_defaults(func=validate)

    command = subparsers.add_parser("validate-source")
    command.add_argument("--metadata", required=True)
    command.add_argument("--reference-eigenval", required=True)
    command.add_argument("--interpolated", required=True)
    command.add_argument("--report", required=True)
    command.add_argument("--tolerance", type=float, default=0.02)
    command.set_defaults(func=validate_source)

    command = subparsers.add_parser("prepare-scan")
    command.add_argument("--mesh", type=int, default=18)
    command.add_argument("--output", required=True)
    command.set_defaults(func=prepare_scan)

    command = subparsers.add_parser("scan-report")
    command.add_argument("--metadata", required=True)
    command.add_argument("--kpoints", required=True)
    command.add_argument("--data", required=True)
    command.add_argument("--report", required=True)
    command.set_defaults(func=scan_report)

    command = subparsers.add_parser("source-scan-report")
    command.add_argument("--metadata", required=True)
    command.add_argument("--eigenval", required=True)
    command.add_argument("--mesh", required=True)
    command.add_argument("--report", required=True)
    command.set_defaults(func=source_scan_report)

    command = subparsers.add_parser("plot")
    command.add_argument("--metadata", required=True)
    command.add_argument("--band-data", required=True)
    command.add_argument("--labels", required=True)
    command.add_argument("--emin", type=float, default=-18.0)
    command.add_argument("--png", required=True)
    command.add_argument("--pdf", required=True)
    command.add_argument("--csv", required=True)
    command.set_defaults(func=plot_bands)

    command = subparsers.add_parser("write-results")
    command.add_argument("--metadata", required=True)
    command.add_argument("--mesh-gap", required=True)
    command.add_argument("--validation", required=True)
    command.add_argument("--source-validation")
    command.add_argument("--scan", required=True)
    command.add_argument("--output", required=True)
    command.set_defaults(func=write_results)
    return parser


def main() -> None:
    parser = build_parser()
    arguments = parser.parse_args()
    arguments.func(arguments)


if __name__ == "__main__":
    main()
